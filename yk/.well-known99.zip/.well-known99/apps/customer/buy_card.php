<!doctype html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="generator" content="">
    <title>Finwallapp - Mobile HTML template</title>

    <!-- manifest meta -->
    <meta name="apple-mobile-web-app-capable" content="yes">

    <!-- Favicons -->
    <link rel="apple-touch-icon" href="img/favicon180.png" sizes="180x180">
    <link rel="icon" href="img/favicon32.png" sizes="32x32" type="image/png">
    <link rel="icon" href="img/favicon16.png" sizes="16x16" type="image/png">

    <!-- Material icons-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <!-- Google fonts-->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">

    <!-- swiper CSS -->
    <link href="vendor/swiper/css/swiper.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet" id="style">
</head>

<body class="body-scroll d-flex flex-column h-100 menu-overlay" data-page="products">
    <!-- screen loader -->
    <div class="container-fluid h-100 loader-display">
        <div class="row h-100">
            <div class="align-self-center col">
                <div class="logo-loading">
                    <div class="icon icon-100 mb-4 rounded-circle">
                        <img src="img/favicon144.png" alt="" class="w-100">
                    </div>
                    <h4 class="text-default">Finwallapp</h4>
                    <p class="text-secondary">Mobile HTML template</p>
                    <div class="loader-ellipsis">
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>




    <!-- Begin page content -->
    <main class="flex-shrink-0 main">
        <!-- Fixed navbar -->
        <header class="header">
            <div class="row">
                <div class="col-auto px-0">
                    <button class="menu-btn btn btn-40 btn-link back-btn" type="button">
                        <span class="material-icons">keyboard_arrow_left</span>
                    </button>
                </div>
                <div class="text-left col align-self-center">
                    <a class="navbar-brand" href="#">
                        <h5 class="mb-0">Products</h5>
                    </a>
                </div>
                <div class="ml-auto col-auto">
                    <a href="profile.html" class="avatar avatar-30 shadow-sm rounded-circle ml-2">
                        <figure class="m-0 background">
                            <img src="img/user1.png" alt="">
                        </figure>
                    </a>
                </div>
            </div>
        </header>

        <!-- page content start -->
        <div class="container mb-4 px-0">
            <!-- Swiper -->
            <div class="swiper-container categoriestab1 text-center">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="card bg-default-light">
                            <div class="card-body p-2">
                                <div class="avatar avatar-60 mb-1 rounded">
                                    <div class="background">
                                        <img src="img/image4.jpg" alt="">
                                    </div>
                                </div>
                                <p class="text-default"><small>Men</small></p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="card">
                            <div class="card-body p-2">
                                <div class="avatar avatar-60 mb-1 rounded">
                                    <div class="background">
                                        <img src="img/image7.jpg" alt="">
                                    </div>
                                </div>
                                <p class="text-secondary"><small>Women</small></p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="card">
                            <div class="card-body p-2">
                                <div class="avatar avatar-60 mb-1 rounded">
                                    <div class="background">
                                        <img src="img/image1.jpg" alt="">
                                    </div>
                                </div>
                                <p class="text-secondary"><small>Kids</small></p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="card">
                            <div class="card-body p-2">
                                <div class="avatar avatar-60 mb-1 rounded">
                                    <div class="background">
                                        <img src="img/image9.jpg" alt="">
                                    </div>
                                </div>
                                <p class="text-secondary"><small>Offer Sale</small></p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="card">
                            <div class="card-body p-2">
                                <div class="avatar avatar-60 mb-1 rounded">
                                    <div class="background">
                                        <img src="img/image8.jpg" alt="">
                                    </div>
                                </div>
                                <p class="text-secondary"><small>Acceso.</small></p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="card">
                            <div class="card-body p-2">
                                <div class="avatar avatar-60 mb-1 rounded">
                                    <div class="background">
                                        <img src="img/image4.jpg" alt="">
                                    </div>
                                </div>
                                <p class="text-secondary"><small>Men</small></p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="card">
                            <div class="card-body p-2">
                                <div class="avatar avatar-60 mb-1 rounded">
                                    <div class="background">
                                        <img src="img/image7.jpg" alt="">
                                    </div>
                                </div>
                                <p class="text-secondary"><small>Women</small></p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="card">
                            <div class="card-body p-2">
                                <div class="avatar avatar-60 mb-1 rounded">
                                    <div class="background">
                                        <img src="img/image1.jpg" alt="">
                                    </div>
                                </div>
                                <p class="text-secondary"><small>Kids</small></p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="card">
                            <div class="card-body p-2">
                                <div class="avatar avatar-60 mb-1 rounded">
                                    <div class="background">
                                        <img src="img/image9.jpg" alt="">
                                    </div>
                                </div>
                                <p class="text-secondary"><small>Offer Sale</small></p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="card">
                            <div class="card-body p-2">
                                <div class="avatar avatar-60 mb-1 rounded">
                                    <div class="background">
                                        <img src="img/image8.jpg" alt="">
                                    </div>
                                </div>
                                <p class="text-secondary"><small>Acceso.</small></p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Add Pagination -->
                <div class="swiper-pagination white-pagination text-left mb-3"></div>
            </div>
        </div>
        <div class="main-container">

            <div class="container">
                <!-- Swiper -->
                <div class="swiper-container categories2tab1 text-center mb-4">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <button class="btn btn-sm btn-default active rounded">Everything</button>
                        </div>
                        <div class="swiper-slide">
                            <button class="btn btn-sm btn-outline-default rounded">Bottom Wear</button>
                        </div>
                        <div class="swiper-slide">
                            <button class="btn btn-sm btn-outline-default rounded">Top Wear</button>
                        </div>
                        <div class="swiper-slide">
                            <button class="btn btn-sm btn-outline-default rounded">Trouser</button>
                        </div>
                        <div class="swiper-slide">
                            <button class="btn btn-sm btn-outline-default rounded">Shoes</button>
                        </div>
                    </div>
                    <!-- Add Pagination -->
                    <div class="swiper-pagination white-pagination text-left mb-3"></div>
                </div>
                <div class="row">
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="card border-0 mb-4 overflow-hidden">
                            <div class="card-body h-150 position-relative">
                                <div class="top-right m-2">
                                    <button class="btn btn-sm btn-light btn-rounded btn-40 rounded-circle"><i class="material-icons mt-0 vm">favorite_border</i></button>
                                </div>
                                <div class="bottom-left m-2">
                                    <button class="btn btn-sm btn-default rounded">New</button>
                                </div>
                                <a href="product.html" class="background">
                                    <img src="img/image4.jpg" alt="">
                                </a>
                            </div>
                            <div class="card-body ">
                                <p class="mb-0"><small class="text-secondary">Rockstar</small></p>
                                <a href="product.html">
                                    <p class="mb-0">Men Jacket brown</p>
                                </a>
                                <h5 class="mb-0">$ 39.99</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="card border-0 mb-4 overflow-hidden">
                            <div class="card-body h-150 position-relative">
                                <div class="top-right m-2">
                                    <button class="btn btn-sm btn-light btn-rounded btn-40 rounded-circle text-danger"><i class="material-icons mt-0 vm ">favorite</i></button>
                                </div>
                                <div class="bottom-left m-2">
                                    <button class="btn btn-sm btn-default rounded">New</button>
                                </div>
                                <figure class="background">
                                    <img src="img/image2.jpg" alt="">
                                </figure>
                            </div>
                            <div class="card-body ">
                                <p class="mb-0"><small class="text-secondary">Adididas</small></p>
                                <a href="product.html">
                                    <p class="mb-0">Women Jacket</p>
                                </a>
                                <h5 class="mb-0">$ 49.99</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="card border-0 mb-4 overflow-hidden">
                            <div class="card-body h-150 position-relative">
                                <div class="top-right m-2">
                                    <button class="btn btn-sm btn-light btn-rounded btn-40 rounded-circle text-danger"><i class="material-icons mt-0 vm">favorite</i></button>
                                </div>
                                <div class="bottom-left m-2">
                                    <button class="btn btn-sm btn-default rounded">New</button>
                                </div>
                                <figure class="background">
                                    <img src="img/image5.jpg" alt="">
                                </figure>
                            </div>
                            <div class="card-body ">
                                <p class="mb-0"><small class="text-secondary">Rockstar</small></p>
                                <a href="product.html">
                                    <p class="mb-0">Shorts Uunisex</p>
                                </a>
                                <h5 class="mb-0">$ 28.99</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="card border-0 mb-4 overflow-hidden">
                            <div class="card-body h-150 position-relative">
                                <div class="top-right m-2">
                                    <button class="btn btn-sm btn-light btn-rounded btn-40 rounded-circle"><i class="material-icons mt-0 vm ">favorite_border</i></button>
                                </div>
                                <div class="bottom-left m-2">
                                    <button class="btn btn-sm btn-default rounded">New</button>
                                </div>
                                <figure class="background">
                                    <img src="img/image6.jpg" alt="">
                                </figure>
                            </div>
                            <div class="card-body ">
                                <p class="mb-0"><small class="text-secondary">Mansheri</small></p>
                                <a href="product.html">
                                    <p class="mb-0">Women Jacket</p>
                                </a>
                                <h5 class="mb-0">$ 35.99</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="card border-0 mb-4 overflow-hidden">
                            <div class="card-body h-150 position-relative">
                                <div class="top-right m-2">
                                    <button class="btn btn-sm btn-light btn-rounded btn-40 rounded-circle"><i class="material-icons mt-0 vm">favorite_border</i></button>
                                </div>
                                <div class="bottom-left m-2">
                                    <button class="btn btn-sm btn-default rounded">New</button>
                                </div>
                                <a href="product.html" class="background">
                                    <img src="img/image4.jpg" alt="">
                                </a>
                            </div>
                            <div class="card-body ">
                                <p class="mb-0"><small class="text-secondary">Rockstar</small></p>
                                <a href="product.html">
                                    <p class="mb-0">Men Jacket brown</p>
                                </a>
                                <h5 class="mb-0">$ 39.99</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="card border-0 mb-4 overflow-hidden">
                            <div class="card-body h-150 position-relative">
                                <div class="top-right m-2">
                                    <button class="btn btn-sm btn-light btn-rounded btn-40 rounded-circle text-danger"><i class="material-icons mt-0 vm ">favorite</i></button>
                                </div>
                                <div class="bottom-left m-2">
                                    <button class="btn btn-sm btn-default rounded">New</button>
                                </div>
                                <figure class="background">
                                    <img src="img/image2.jpg" alt="">
                                </figure>
                            </div>
                            <div class="card-body ">
                                <p class="mb-0"><small class="text-secondary">Adididas</small></p>
                                <a href="product.html">
                                    <p class="mb-0">Women Jacket</p>
                                </a>
                                <h5 class="mb-0">$ 49.99</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="card border-0 mb-4 overflow-hidden">
                            <div class="card-body h-150 position-relative">
                                <div class="top-right m-2">
                                    <button class="btn btn-sm btn-light btn-rounded btn-40 rounded-circle text-danger"><i class="material-icons mt-0 vm">favorite</i></button>
                                </div>
                                <div class="bottom-left m-2">
                                    <button class="btn btn-sm btn-default rounded">New</button>
                                </div>
                                <figure class="background">
                                    <img src="img/image5.jpg" alt="">
                                </figure>
                            </div>
                            <div class="card-body ">
                                <p class="mb-0"><small class="text-secondary">Rockstar</small></p>
                                <a href="product.html">
                                    <p class="mb-0">Shorts Uunisex</p>
                                </a>
                                <h5 class="mb-0">$ 28.99</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="card border-0 mb-4 overflow-hidden">
                            <div class="card-body h-150 position-relative">
                                <div class="top-right m-2">
                                    <button class="btn btn-sm btn-light btn-rounded btn-40 rounded-circle"><i class="material-icons mt-0 vm ">favorite_border</i></button>
                                </div>
                                <div class="bottom-left m-2">
                                    <button class="btn btn-sm btn-default rounded">New</button>
                                </div>
                                <figure class="background">
                                    <img src="img/image6.jpg" alt="">
                                </figure>
                            </div>
                            <div class="card-body ">
                                <p class="mb-0"><small class="text-secondary">Mansheri</small></p>
                                <a href="product.html">
                                    <p class="mb-0">Women Jacket</p>
                                </a>
                                <h5 class="mb-0">$ 35.99</h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row text-center">
                    <div class="col-6 col-md-4 col-lg-3 mx-auto">
                        <button class="btn btn-sm btn-outline-secondary rounded">Load More...</button>
                    </div>
                </div>
            </div>
        </div>
    </main>


    <!-- Required jquery and libraries -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- cookie js -->
    <script src="js/jquery.cookie.js"></script>

    <!-- Swiper slider  js-->
    <script src="vendor/swiper/js/swiper.min.js"></script>

    <!-- Customized jquery file  -->
    <script src="js/main.js"></script>
    <script src="js/color-scheme-demo.js"></script>


    <!-- page level custom script -->
    <script src="js/app.js"></script>
    
</body>

</html>
