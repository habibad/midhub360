<?php 
    include "login.check.php";
    include "header.php"; 
?>

        <!-- page content start -->

        <div class="main-container">
            <div class="container">
                <div class="card">
                    <div class="card-body">
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary rounded m-2" data-toggle="modal" data-target="#exampleModal">
                            Launch modal
                        </button>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary rounded m-2" data-toggle="modal" data-target="#exampleModalLong">
                            Launch modal large
                        </button>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary rounded m-2" data-toggle="modal" data-target="#exampleModalScrollable">
                            Launch demo modal scroll
                        </button>

                        <button type="button" class="btn btn-primary rounded m-2" data-toggle="modal" data-target="#exampleModalCenter">
                            Launch demo modal vertical centered
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Modals  -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" style="display: none;" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    ...
                    <div class="container mb-4">
                <div class="card">
                    <div class="card-body text-center ">
                        <div class="row justify-content-equal no-gutters">
                            <div class="col-4 col-md-2 mb-3">
                            <a href="#">
                                <div class="icon icon-50 rounded-circle mb-1 bg-default-light text-default"><span class="material-icons">app_settings_alt</span></div>
                                <p class="text-secondary"><small>Drive</small></p>
                            </a>
                            </div>
                            <div class="col-4 col-md-2 mb-3">
                            <a href="#">
                            <img src="../img/icon/package.png" class="home-icon" alt="">                                 
                                <p class="text-secondary"><small>Package</small></p>
                            </a>
                            </div>
                            <div class="col-4 col-md-2 mb-3">
                            <a href="send_bkash.php">                                
                                <img src="../img/icon/bKash.png" class="home-icon" alt="">                                
                                <p class="text-secondary"><small>bKash</small></p>                                
                            </a>
                            </div>
                            <div class="col-4 col-md-2 mb-3">
                            <a href="#">                                
                                <img src="../img/icon/nagad.png" class="home-icon" alt="">
                                <p class="text-secondary"><small>Rocket</small></p>
                            </a>
                            </div>
                            <div class="col-4 col-md-2 mb-3">
                            <a href="#">
                            <img src="../img/icon/rocket.png" class="home-icon" alt="">                                
                                <p class="text-secondary"><small>Nagad</small></p>
                            </a>
                            </div>
                            <div class="col-4 col-md-2 mb-3">
                            <a href="#">
                                <div class="icon icon-50 rounded-circle mb-1 bg-default-light text-default"><span class="material-icons">wb_incandescent</span></div>
                                <p class="text-secondary"><small>Bill Pay</small></p>
                            </a>
                            </div>

                            <div class="col-4 col-md-2 mb-3">
                            <a href="#">
                                <div class="icon icon-50 rounded-circle mb-1 bg-default-light text-default"><span class="material-icons">phone_iphone</span></div>
                                <p class="text-secondary"><small>MNP</small></p>
                            </a>
                            </div>

                            <div class="col-4 col-md-2 mb-3">
                            <a href="#">
                            <img src="../img/icon/upay.png" class="home-icon" alt="">
                                <p class="text-secondary"><small>Upay</small></p>
                            </a>
                            </div>

                            <div class="col-4 col-md-2 mb-3">
                            <a href="#">
                                <div class="icon icon-50 rounded-circle mb-1 bg-default-light text-default"><span class="material-icons">account_balance</span></div>
                                <p class="text-secondary"><small>Banking</small></p>
                            </a>
                            </div>
                            
                        </div>
                       
                    </div>
                </div>
            </div>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>

            </div>
        </div>
    </div>
    <div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    ...
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalScrollableTitle">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h5>What is Lorem Ipsum?</h5>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>

                    <h5>Why do we use it?</h5>
                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>

                    <h5>Where does it come from?</h5>
                    <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>

                    <p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    ...
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>


<?php 
    include "footer.php"; 
?>
