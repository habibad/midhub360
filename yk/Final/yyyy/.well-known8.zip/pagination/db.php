<?php
// SQL server connection information
$sql_details = array(
  'user' => 'aanonda_eload024',
    'pass' => 'V1911Z%cR_@@',
    'db'   => 'aanonda_Eload24',
    'host' => 'localhost'
);
?>